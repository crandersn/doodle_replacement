function validateNewPollForm () {

    console.log("form called")
    var title = document.forms["pollForm"]["title"].value;
    var location = document.forms["pollForm"]["location"].value;
    var expiration_date = document.forms["pollForm"]["expiration_date"].value;
    var votes_per_timeslot = document.forms["pollForm"]["votes_per_timeslot"].value;
    var votes_per_participant = document.forms["pollForm"]["votes_per_person"].value;


}
;
